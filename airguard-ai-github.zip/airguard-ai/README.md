# AirGuard AI — Air Particle & Pollution Detection

AirGuard AI is a portfolio-ready prototype for monitoring visible air-pollution indicators from camera images and presenting air-quality analytics in a dashboard.

> **Important:** Camera-based object detection does not directly measure PM2.5 or PM10. Real particulate concentration requires calibrated air-quality sensors. This prototype treats camera detections as visual pollution indicators and keeps sensor values as optional inputs.

## Features
- Upload an image and run AI object detection
- Detect pollution-related visual classes when a compatible YOLO model is provided
- Draw bounding boxes and confidence scores
- Estimate a visual pollution indicator from detections
- Optional PM2.5 / PM10 sensor readings
- Streamlit dashboard for demonstration
- Portfolio dashboard mockup in `assets/`

## Tech Stack
Python · Streamlit · OpenCV · Ultralytics YOLO · NumPy · Pillow

## Project Structure
```text
airguard-ai/
├── app.py
├── detector.py
├── analytics.py
├── requirements.txt
├── .gitignore
├── README.md
└── assets/
    └── airguard-dashboard.png
```

## Run locally
```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install and run:
```bash
pip install -r requirements.txt
streamlit run app.py
```

## AI Model
Place a compatible Ultralytics YOLO weights file at:
```text
models/best.pt
```
The model should contain classes relevant to your trained use case, such as `smoke`, `dust`, or other visible pollution indicators.

If no custom model is present, the app still runs and explains how to add one.

## Portfolio note
`assets/airguard-dashboard.png` is a UI concept/mockup created for portfolio presentation. Replace it with real screenshots once the application is connected to your trained model and/or sensor hardware.
