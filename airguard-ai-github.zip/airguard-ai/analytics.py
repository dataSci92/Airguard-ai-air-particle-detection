from collections import Counter


def summarize_detections(detections: list[dict]) -> dict:
    counts = Counter(d["class"] for d in detections)
    total = len(detections)

    if total == 0:
        indicator = "Low"
    elif total < 5:
        indicator = "Moderate"
    else:
        indicator = "High"

    avg_conf = (
        sum(d["confidence"] for d in detections) / total
        if total else 0.0
    )

    return {
        "total_detections": total,
        "classes": dict(counts),
        "average_confidence": avg_conf,
        "visual_pollution_indicator": indicator,
    }
